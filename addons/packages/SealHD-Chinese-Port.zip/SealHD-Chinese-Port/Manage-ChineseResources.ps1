param(
    [ValidateSet('Install', 'Restore')][string]$Action = 'Install',
    [string]$GameDirectory = 'D:\Steam\steamapps\common\Seal of Evil'
)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name SOE -ErrorAction SilentlyContinue) {
    throw 'Close Seal of Evil before installing or restoring language resources.'
}
$root = [IO.Path]::GetFullPath($GameDirectory).TrimEnd('\')
if (!(Test-Path -LiteralPath (Join-Path $root 'SOE.EXE'))) { throw 'Game executable not found.' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$sourceFolder = if ($Action -eq 'Install') { 'payload' } else { 'english-backup' }
$mutableNames = @($manifest.Files | ForEach-Object { $_.Path.Replace('/','\') })
$protectedNames = @('SOE.EXE','dinput8.dll','D3D8.dll','DDraw.dll','D3DImm.dll','Gfx3d.dll','ERRelive.dll','Mfx.dll','OmUtil.dll','SealHD.ini','dgVoodoo.conf')
$protected = @{}
foreach ($name in $protectedNames) {
    $path = Join-Path $root $name
    if (($mutableNames -notcontains $name) -and (Test-Path -LiteralPath $path)) { $protected[$name] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
}
$operations = @()
foreach ($entry in $manifest.Files) {
    if (($entry.Path -notmatch '^Dlg/[A-Za-z0-9_]+\.dlg$') -and ($entry.Path -notin @('Data/face.txt','font/UIPoint.tib','ERRelive.dll'))) { throw 'Unexpected resource path in manifest.' }
    $target = [IO.Path]::GetFullPath((Join-Path $root $entry.Path))
    if (!$target.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Resource path is outside the game folder.' }
    $source = Join-Path (Join-Path $PSScriptRoot $sourceFolder) $entry.Path
    $desiredHash = if ($Action -eq 'Install') { $entry.ChineseSha256 } else { $entry.EnglishSha256 }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $desiredHash) { throw ('Package hash mismatch: ' + $entry.Path) }
    $currentHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($currentHash -ne $entry.EnglishSha256 -and $currentHash -ne $entry.ChineseSha256) {
        throw ('Game resource has changed independently; nothing has been installed: ' + $entry.Path)
    }
    if ($currentHash -ne $desiredHash) {
        $operations += [pscustomobject]@{ Entry=$entry; Source=$source; Target=$target; DesiredHash=$desiredHash; BeforeBytes=[IO.File]::ReadAllBytes($target) }
    }
}
$written = @()
try {
    foreach ($operation in $operations) {
        $temporary = $operation.Target + '.chinese-port-' + [Guid]::NewGuid().ToString('N')
        [IO.File]::WriteAllBytes($temporary, [IO.File]::ReadAllBytes($operation.Source))
        Move-Item -LiteralPath $temporary -Destination $operation.Target -Force
        $written += $operation
        if ((Get-FileHash -LiteralPath $operation.Target -Algorithm SHA256).Hash -ne $operation.DesiredHash) { throw 'Installed resource verification failed.' }
    }
    foreach ($name in $protected.Keys) {
        if ((Get-FileHash -LiteralPath (Join-Path $root $name) -Algorithm SHA256).Hash -ne $protected[$name]) { throw ('A protected game/HD file changed during this operation: ' + $name) }
    }
} catch {
    foreach ($operation in $written) { [IO.File]::WriteAllBytes($operation.Target, $operation.BeforeBytes) }
    throw
}
[pscustomobject]@{
    Action=$Action; GameDirectory=$root; CompletedUtc=[DateTime]::UtcNow.ToString('o');
    ChangedFiles=$operations.Count; ProtectedFileHashes=$protected
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'last-operation.json') -Encoding UTF8
Write-Host ($Action + ' completed. Changed resource files: ' + $operations.Count)
Write-Host 'Game executable, HD patch, graphics wrappers, settings and saved games were preserved.'
Write-Host 'The engine DLL differs only in map-name string data; its code remains unchanged.'
