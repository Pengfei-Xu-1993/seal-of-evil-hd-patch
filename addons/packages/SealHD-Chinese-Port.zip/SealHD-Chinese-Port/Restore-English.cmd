@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Manage-ChineseResources.ps1" -Action Restore %*
pause
