@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Manage-SkillMod.ps1" -Action Restore %*
pause
