param(
    [ValidateSet('Install','Restore')][string]$Action = 'Install',
    [string]$GameDirectory = 'D:\Steam\steamapps\common\Seal of Evil'
)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name SOE -ErrorAction SilentlyContinue) { throw 'Close Seal of Evil before changing skill definitions.' }
$gameRoot = [IO.Path]::GetFullPath($GameDirectory).TrimEnd('\')
if (!(Test-Path -LiteralPath (Join-Path $gameRoot 'SOE.EXE'))) { throw 'Game executable not found.' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$folder = if ($Action -eq 'Install') { 'payload' } else { 'original' }
$operations = @()
foreach ($entry in $manifest.Files) {
    if ($entry.Path -notin @('Data/skill_role.txt','Data/skill_enhance.txt','ObjMdl/MethodMdl.ini','ObjMdl/MethodUnit_Mdl.ini','ObjMdl/RoleMdl.rmd')) { throw 'Unexpected file in skill manifest.' }
    $target = [IO.Path]::GetFullPath((Join-Path $gameRoot $entry.Path))
    if (!$target.StartsWith($gameRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside game directory.' }
    $source = Join-Path (Join-Path $PSScriptRoot $folder) $entry.Path
    $desiredHash = if ($Action -eq 'Install') { $entry.ModifiedSha256 } else { $entry.OriginalSha256 }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $desiredHash) { throw ('Package hash mismatch: ' + $entry.Path) }
    $currentHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($currentHash -ne $entry.OriginalSha256 -and $currentHash -ne $entry.ModifiedSha256 -and @($entry.CompatiblePreviousSha256) -notcontains $currentHash) { throw ('This file was edited separately. No files changed: ' + $entry.Path) }
    if ($currentHash -ne $desiredHash) {
        $operations += [pscustomobject]@{ Path=$entry.Path; Source=$source; Target=$target; DesiredHash=$desiredHash; ExpectedHash=$currentHash; Before=[IO.File]::ReadAllBytes($target) }
    }
}
$written = @()
try {
    foreach ($operation in $operations) {
        if (Get-Process -Name SOE -ErrorAction SilentlyContinue) { throw 'The game started during installation.' }
        if ((Get-FileHash -LiteralPath $operation.Target -Algorithm SHA256).Hash -ne $operation.ExpectedHash) { throw ('File changed after validation: ' + $operation.Path) }
        $temporary = $operation.Target + '.skill-mod-' + [Guid]::NewGuid().ToString('N')
        [IO.File]::WriteAllBytes($temporary, [IO.File]::ReadAllBytes($operation.Source))
        Move-Item -LiteralPath $temporary -Destination $operation.Target -Force
        $written += $operation
        if ((Get-FileHash -LiteralPath $operation.Target -Algorithm SHA256).Hash -ne $operation.DesiredHash) { throw 'Installed file verification failed.' }
    }
} catch {
    foreach ($operation in $written) { [IO.File]::WriteAllBytes($operation.Target, $operation.Before) }
    throw
}
[pscustomobject]@{Action=$Action;GameDirectory=$gameRoot;CompletedUtc=[DateTime]::UtcNow.ToString('o');ChangedFiles=$operations.Count} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'last-operation.json') -Encoding UTF8
Write-Host ($Action + ' completed. Changed files: ' + $operations.Count)
